<?php

$tablica = json_decode(file_get_contents('../json/tablica.json'), true);
$currentPage = 'index'; 

?>

<!DOCTYPE html>
<html lang="hr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="shortcut icon" href="../slike/favicon.ico" type="image/x-icon">
  <title>UEFA Liga nacija</title>
  <style>
    .team {
      display: flex;
      align-items: center;
      flex-direction: column;
    }
    .team img {
      height: 24px;
      width: auto;
    }
    .match-row {
      display: flex;
      align-items: flex-start;
      justify-content: center;
      gap: 16px;
      flex-wrap: nowrap;
    }
    .finale-section {
      margin-top: 120px;
    }
    .finale-section h4 {
      font-size: 2.5rem;
      font-weight: bold;
    }
    .finale-match {
      font-size: 2rem;
      font-weight: bold;
    }
    .third-place {
      margin-top: 60px;
    }
    .winner {
      font-weight: bold;
    }
    .scorers {
      font-size: 0.9rem;
      color: #555;
      text-align: left;
      margin-top: 6px;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .scorer-item {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 2px 0;
    }
    .scorer-item img {
      height: 18px;
      width: 18px;
      object-fit: contain;
      display: block;
    }
    .gradient-header {
      background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
    }
    .gradient-header .navbar-brand,
    .gradient-header .navbar-text {
      color: white !important;
    }
  </style>
</head>
<body>
    <nav class="navbar navbar-light px-5 py-3 gradient-header">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <a href="index.php">
                <img src="../slike/logo.png" alt="Logo" style="height: 90px;">
            </a>
            <div class="d-flex align-items-center gap-4">
                <a href="index.php" class="btn btn-outline-light btn-sm <?php echo ($currentPage == 'index') ? 'active' : ''; ?>">Početna</a>
                <a href="najboljiIgraci.php" class="btn btn-outline-light btn-sm <?php echo ($currentPage == 'najbolji') ? 'active' : ''; ?>">Najbolji igrači</a>
                <a href="prikazUtakmice.php" class="btn btn-outline-light btn-sm <?php echo ($currentPage == 'utakmice') ? 'active' : ''; ?>">Detalji utakmica</a>
                <span class="fs-4 fw-bold navbar-text">UEFA Liga nacija - Sezona 2022./23.</span>
            </div>
        </div>
    </nav>

  <div class="container mt-5">
    <h2 class="text-center">Playoff</h2>
  </div>

  <div class="container mt-5">
    <h2 class="text-center">Playoff Shema - Sezona 2022./23.</h2>

    <div class="row text-center mt-4">
      <div class="col-md-4">
        <h4>Polufinale 1</h4>
        <p class="match-row">
          <span class="team">
            <img src="../slike/grbovi/nizozemska.png" alt="Nizozemska"> Nizozemska
            <span class="scorers">
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Malen D.</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Lang N.</span>
            </span>
          </span>
          <strong>2:4</strong>
          <span class="team winner">
            <img src="../slike/grbovi/hrvatska.png" alt="Hrvatska"> Hrvatska
            <span class="scorers">
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Kramarić A.</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Pašalić M.</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Petković B.</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Modrić L.</span>
            </span>
          </span>
        </p>
      </div>

      <div class="col-md-4 third-place">
        <h4>Utakmica za 3. mjesto</h4>
        <p class="match-row">
          <span class="team">
            <img src="../slike/grbovi/nizozemska.png" alt="Nizozemska"> Nizozemska
            <span class="scorers">
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Bergwijn S.</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Wijnaldum G.</span>
            </span>
          </span>
          <strong>2:3</strong>
          <span class="team winner">
            <img src="../slike/grbovi/italija.png" alt="Italija"> Italija
            <span class="scorers">
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Dimarco F.</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Frattesi D.</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Chiesa F.</span>
            </span>
          </span>
        </p>
      </div>

      <div class="col-md-4">
        <h4>Polufinale 2</h4>
        <p class="match-row">
          <span class="team winner">
            <img src="../slike/grbovi/spanjolska.png" alt="Španjolska"> Španjolska
            <span class="scorers">
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Pino Y.</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Joselu</span>
            </span>
          </span>
          <strong>2:1</strong>
          <span class="team">
            <img src="../slike/grbovi/italija.png" alt="Italija"> Italija
            <span class="scorers">
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Immobile C.</span>
            </span>
          </span>
        </p>
      </div>
    </div>

    <div class="row text-center finale-section">
      <div class="col-md-8 offset-md-2">
        <h4>Finale</h4>
        <p class="match-row finale-match">
          <span class="team">
            <img src="../slike/grbovi/hrvatska.png" alt="Hrvatska"> Hrvatska
            <span class="scorers">
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Vlašić N.</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Majer L.</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Perišić I.</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Modrić L.</span>
            </span>
          </span>
          <span>0:0 (4:5 pen)</span>
          <span class="team winner">
            <img src="../slike/grbovi/spanjolska.png" alt="Španjolska"> Španjolska
            <span class="scorers">
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Joselu</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Rodri</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Merino</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Asensio</span>
              <span class="scorer-item"><img src="../slike/strijelci/icon-scored.png"> Carvajal</span>
            </span>
          </span>
        </p>
      </div>
    </div>
  </div>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Završni poredak</h2>
        <table class="table text-center table-bordered" style="max-width: 600px; margin: 0 auto;">
        <thead class="table-dark">
            <tr>
             <th>Mjesto</th>
            <th>Država</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($tablica as $red): ?>
          <tr style="background-color:
            <?php 
              echo match($red['pozicija']) {
                '1' => '#FFD700',
                '2' => '#C0C0C0',
                '3' => '#CD7F32',
                default => '#f0f0f0'
              };
            ?>">
            <td><?= $red['pozicija'] ?>.</td>
            <td class="d-flex align-items-center justify-content-center gap-2">
              <img src="<?= $red['badge'] ?>" alt="<?= $red['drzava'] ?>" height="24"> <?= $red['drzava'] ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <footer class="mt-5 py-4 text-white text-center" style="background: linear-gradient(to right, #0f2027, #203a43, #2c5364);">
    <div>
      Toni Jelić - 0246117657
      <br>
      Mihael Klemeš - 0246116387
    </div>
  </footer>
</body>
</html>
