<?php 
    $xml = simplexml_load_file('../xml/strijelci.xml');
    $currentPage = 'najbolji';
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="shortcut icon" href="../slike/favicon.ico" type="image/x-icon">
    <title>UEFA Liga nacija</title>
    <style>
        .gradient-header {
            background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
        }
        .gradient-header .navbar-brand,
        .gradient-header .navbar-text {
            color: white !important;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-light px-5 py-3 gradient-header">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <a href="index.php">
                <img src="../slike/logo.png" alt="Logo" style="height: 90px;">
            </a>
            <div class="d-flex align-items-center gap-4">
                <a href="index.php" class="btn btn-outline-light btn-sm <?php echo ($currentPage == 'index') ? 'active' : ''; ?>">Početna</a>
                <a href="najboljiIgraci.php" class="btn btn-outline-light btn-sm <?php echo ($currentPage == 'najbolji') ? 'active' : ''; ?>">Najbolji igrači</a>
                <a href="prikazUtakmice.php" class="btn btn-outline-light btn-sm <?php echo ($currentPage == 'utakmice') ? 'active' : ''; ?>">Detalji utakmica</a>
                <span class="fs-4 fw-bold navbar-text">UEFA Liga nacija - Sezona 2022./23.</span>
            </div>
        </div>
    </nav>

    <div class="container mt-4 mb-4">
        <h1 class="text-center">Najbolji strijelci</h1>
    </div>

    <table class="table text-center">
        <thead>
            <tr>
                <th>#</th>
                <th>Igrač</th>
                <th>Golovi</th>
                <th>Reprezentacija</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $firstRow = true;
            foreach ($xml->strijelac as $strijelac): 
                $rowClass = $firstRow ? 'table-warning' : '';
                $firstRow = false;
            ?>
            <tr class="<?php echo $rowClass; ?>">
                <td><?php echo $strijelac->mjesto; ?></td>
                <td><?php echo $strijelac->ime; ?></td>
                <td><?php echo $strijelac->brojGolova; ?></td>
                <td><img src="<?php echo $strijelac->klub; ?>" alt="Zastava" width="32"></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="container mt-5 mb-4">
        <h1 class="text-center">Najbolji asistenti</h1>
    </div>

    <table class="table text-center">
        <thead>
            <tr>
                <th>#</th>
                <th>Igrač</th>
                <th>Asistencije</th>
                <th>Reprezentacija</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $firstRow = true;
            foreach ($xml->asistent as $asistent): 
                $rowClass = $firstRow ? 'table-warning' : '';
                $firstRow = false;
            ?>
            <tr class="<?php echo $rowClass; ?>">
                <td><?php echo $asistent->mjesto; ?></td>
                <td><?php echo $asistent->ime; ?></td>
                <td><?php echo $asistent->brojAsistencija; ?></td>
                <td><img src="<?php echo $asistent->klub; ?>" alt="Zastava" width="32"></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

  <footer class="mt-5 py-4 text-white text-center" style="background: linear-gradient(to right, #0f2027, #203a43, #2c5364);">
    <div>
      Toni Jelić - 0246117657
      <br>
      Mihael Klemeš - 0246116387
    </div>
  </footer>
</body>
</html>
